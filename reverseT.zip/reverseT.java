import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;
class Ap {
int data;
Ap left;
Ap right;
public Ap(int data) {
this.data = data;
}
}
public class RevTra{
public void reverseBFS(Ap root) {
Queue<Ap> q = new LinkedList<Ap>();
Stack<Ap> s = new Stack<Ap>();
q.add(root);
while (!q.isEmpty()) {
Ap n = q.remove();
if (n.left!= null){
q.add(n.left);
}
if (n.right!= null) {
q.add(n.right);
}
s.add(n);
}
while (s.isEmpty() == false) {
System.out.print(s.pop().data + " ");
}
}
public static void main(String[] args) {
Ap root = new Ap(1);
root.left = new Ap(2);
root.right = new Ap(3);
root.left.left = new Ap(4);
root.left.right = new Ap(5);
root.right.left = new Ap(6);
root.right.right = new Ap(7);
RevTra i = new RevTra();
i.reverseBFS(root);
}
}
}
